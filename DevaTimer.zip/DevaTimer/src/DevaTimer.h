/*
  Example: BasicInterval
  Library: DevaTimer
  By Deva DIY
  https://devadiy.com
*/

#ifndef DEVATIMER_H
#define DEVATIMER_H

#include <Arduino.h>
#include <functional>

class DevaTimer {
public:
  using Callback = std::function<void()>;

  DevaTimer();

  void setInterval(unsigned long delayMs, Callback cb);
  void setTimeout(unsigned long delayMs, Callback cb);
  bool update();
  void changeInterval(unsigned long delayMs);
  void remove();          // ยกเลิก timer
  bool isActive() const;  // เช็คว่าใช้งานอยู่ไหม
  void pause();           // หยุดชั่วคราว
  void resume();          // กลับมาทำงานต่อ (เริ่มนับรอบใหม่)
  bool isPaused() const;  // เช็คว่ากำลัง pause อยู่ไหม

private:
  unsigned long lastTime = 0;
  unsigned long interval = 0;
  Callback cb = nullptr;
  bool paused = false;
  bool runOnce = false;
};

#endif
