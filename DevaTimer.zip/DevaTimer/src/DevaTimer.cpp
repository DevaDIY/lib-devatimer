#include "DevaTimer.h"

// Constructor: เริ่มต้นค่าเมื่อสร้างออบเจกต์
DevaTimer::DevaTimer() {
  // how:
  // - บันทึกเวลาเริ่มต้นไว้ที่ lastTime เพื่อใช้เป็นจุดอ้างอิงแรก
  lastTime = millis();
}

// ตั้งค่าช่วงเวลาและฟังก์ชันที่จะให้ทำงาน (Callback)
void DevaTimer::setInterval(unsigned long delayMs, Callback callback) {
  // how:
  // 1) เก็บระยะเวลา (ms) ลงใน interval
  // 2) เก็บฟังก์ชันที่จะให้รันลงใน cb
  // 3) อัปเดต lastTime เป็นเวลาปัจจุบันเพื่อเริ่มนับใหม่
  // 4) ยกเลิกสถานะ pause เผื่อก่อนหน้านี้เคย pause
  // 5) กำหนด runOnce = false เพราะ timer นี้ต้องทำงานซ้ำ
  interval = delayMs;
  cb = callback;
  lastTime = millis();
  paused = false;
  runOnce = false;
}

// ตั้งค่าเฉพาะระยะเวลาหน่วงใหม่ โดยไม่เปลี่ยนฟังก์ชัน Callback
void DevaTimer::changeInterval(unsigned long delayMs) {
  // how:
  // 1) อัปเดตค่า interval ใหม่
  // 2) รีเซ็ต lastTime ให้นับเริ่มจากตอนนี้
  // 3) ยกเลิกสถานะ pause เพื่อให้ timer กลับมาทำงาน
  // 4) ไม่เปลี่ยน callback และไม่เปลี่ยนโหมด runOnce
  interval = delayMs;
  lastTime = millis();
  paused = false;   // เริ่มงานใหม่ -> ไม่ pause
}

void DevaTimer::setTimeout(unsigned long delayMs, Callback callback) {
  // how:
  // 1) เก็บระยะเวลาที่ต้องการรอไว้ใน interval
  // 2) เก็บฟังก์ชัน callback ที่จะให้ทำงานเมื่อครบเวลา
  // 3) บันทึกเวลาเริ่มต้นใหม่จาก millis() เพื่อเริ่มนับจาก "ตอนนี้"
  // 4) ยกเลิกสถานะ pause เผื่อก่อนหน้านี้ timer ถูก pause ไว้
  // 5) ตั้ง runOnce = true เพื่อบอกว่า timer นี้ต้องทำงาน "ครั้งเดียว"
  //    เมื่อครบเวลา update() จะเรียก callback แล้ว remove() อัตโนมัติ
  interval = delayMs;
  cb = callback;
  lastTime = millis();
  paused = false;
  runOnce = true;
}

// ฟังก์ชันหลักที่ต้องเรียกใน loop() เพื่อตรวจสอบเวลา
bool DevaTimer::update() {
  // how:
  // 1) เช็คก่อนว่ามีฟังก์ชัน Callback (cb) หรือตั้งเวลาไว้หรือไม่
  // 2) อ่านเวลาปัจจุบันด้วย millis()
  // 3) คำนวณ: ถ้าเวลาปัจจุบัน - เวลาล่าสุด >= ช่วงวันที่ตั้งไว้ (Interval)
  //    - อัปเดต lastTime เป็นเวลาปัจจุบัน (เพื่อเริ่มรอบถัดไป)
  //    - สั่งรันฟังก์ชัน cb() ที่ฝากไว้
  //    - return true เพื่อบอกว่า Timer ทำงานแล้วในรอบนี้
  if (!cb || interval == 0 || paused) return false;

  unsigned long now = millis();
  if (now - lastTime >= interval) {
    Callback currentCb = cb;

    if (runOnce) {
      remove();           // timeout ทำครั้งเดียวแล้วลบตัวเอง
    } else {
      lastTime += interval;
    }

    currentCb();
    return true;
  }
  return false;
}

// ยกเลิกการทำงานของ Timer
void DevaTimer::remove() {
  // how:
  // - เคลียร์ฟังก์ชัน Callback ให้เป็นค่าว่าง (nullptr)
  // - ตั้งค่า interval เป็น 0 เพื่อหยุดการเช็คใน update()
  cb = nullptr;
  interval = 0;
  lastTime = 0;
  paused = false;
  runOnce = false;
}

// ตรวจสอบว่า Timer นี้กำลังทำงานอยู่หรือไม่
bool DevaTimer::isActive() const {
  // how:
  // - เช็คว่ามีการฝากฟังก์ชัน (cb) ไว้หรือไม่ ถ้ามีแสดงว่า Timer ยังทำงานอยู่
  return cb != nullptr;
}

// หยุดชั่วคราว
void DevaTimer::pause() {
  if (cb && interval > 0) {
    paused = true;
  }
}

// กลับมาทำงานต่อ (เริ่มนับใหม่)
void DevaTimer::resume() {
  if (cb && interval > 0 && paused) {
    lastTime = millis();   // เริ่มนับใหม่จากตอน resume
    paused = false;
  }
}

// ตรวจสอบว่า Timer นี้ pause อยู่หรือไม่
bool DevaTimer::isPaused() const {
  return paused;
}