// DevaTimer.h
#ifndef DEVATIMER_H
#define DEVATIMER_H

#include <Arduino.h>
#include <functional> // สำหรับ std::function

class DevaTimer {
public:
    DevaTimer(); // Constructor
    void setInterval(int delay, std::function<void()> callback); // ตั้งค่า delay และ callback
    void update(); // อัปเดต timer

private:
    unsigned long timeStamp; // บันทึกเวลาล่าสุด
};

#endif
