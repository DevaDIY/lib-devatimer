/*
  Example: BasicTimeout
  Library: DevaTimer
  By Deva DIY
  https://devadiy.com
*/

#include <DevaTimer.h>

DevaTimer onceTimer;

void setup() {
  Serial.begin(115200);

  onceTimer.setTimeout(3000, []() {
    Serial.println("ครบ 3 วินาที ทำงานครั้งเดียว");
  });
}

void loop() {
  onceTimer.update();
}