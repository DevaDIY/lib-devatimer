/*
  Example: BasicInterval
  Library: DevaTimer
  By Deva DIY
  https://devadiy.com
*/

#include <DevaTimer.h>

DevaTimer blinkTimer;

void setup() {
  pinMode(2, OUTPUT);

  blinkTimer.setInterval(1000, []() {
    digitalWrite(2, !digitalRead(2));
  });
}

void loop() {
  blinkTimer.update();
}