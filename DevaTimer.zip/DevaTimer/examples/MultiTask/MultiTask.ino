/*
  Example: MultiTask
  Library: DevaTimer
  By Deva DIY
  https://devadiy.com
*/

#include <DevaTimer.h>

DevaTimer sensorTimer;
DevaTimer serialTimer;
DevaTimer relayTimer;

void setup() {
  Serial.begin(115200);

  sensorTimer.setInterval(500, []() {
    Serial.println("Read sensor");
  });

  serialTimer.setInterval(1000, []() {
    Serial.println("Send serial log");
  });

  relayTimer.setInterval(3000, []() {
    Serial.println("Toggle relay");
  });
}

void loop() {
  sensorTimer.update();
  serialTimer.update();
  relayTimer.update();
}