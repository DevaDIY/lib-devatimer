#include <DevaTimer.h>

DevaTimer timer; // สร้างออบเจกต์ของ MyTimer

void setup() {
  Serial.begin(115200);
}

void loop() {
  timer.setInterval(1000, []() {
    Serial.println("Works every 1000 milliseconds");
  });
}
