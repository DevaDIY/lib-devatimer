/*
  Example: PauseResume
  Library: DevaTimer
  By Deva DIY
  https://devadiy.com
*/

#include <DevaTimer.h>

DevaTimer taskTimer;
bool pausedOnce = false;
bool resumedOnce = false;

void setup() {
  Serial.begin(115200);

  taskTimer.setInterval(1000, []() {
    Serial.println("Timer running...");
  });
}

void loop() {
  taskTimer.update();

  if (millis() > 5000 && !pausedOnce) {
    taskTimer.pause();
    Serial.println("Pause timer");
    pausedOnce = true;
  }

  if (millis() > 9000 && !resumedOnce) {
    taskTimer.resume();
    Serial.println("Resume timer");
    resumedOnce = true;
  }
}