// DevaTimer.cpp
#include "DevaTimer.h"

// Constructor
DevaTimer::DevaTimer() {
    timeStamp = millis(); // เริ่มต้นค่า timeStamp
}

void DevaTimer::setInterval(int delay, std::function<void()> callback) {
    if (millis() - timeStamp >= delay) {
        timeStamp = millis();
        callback(); // เรียกใช้ฟังก์ชัน callback
    }
}

void DevaTimer::update() {
    // อาจจะเรียก setInterval ในที่นี้เพื่อให้ใช้งานได้สะดวก
}
